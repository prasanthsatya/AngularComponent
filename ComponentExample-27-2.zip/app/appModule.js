var app=angular.module("myApp",[]);
app.controller("myCtrl",function($scope, countryData){
	var handleSuccess = function(data, status) {
	        $scope.JsonData = data;
	        $scope.usa=$scope.JsonData.countries.USA;
			$scope.aus=$scope.JsonData.countries.AUS;
			$scope.ca=$scope.JsonData.countries.CA;
			$scope.nz=$scope.JsonData.countries.NZ;
			//getSelectedData(); 			
	   	};
		countryData.getJsonData().success(handleSuccess);
			
		//$scope.countryDataInfo = $scope.usa;
		//console.log($scope.countryDataInfo);
		/*function getSelectedData(){	

			function myFunction($event)	{
			alert("aSome");
			consoleLog($event);	
			$scope.countrydatainfo = $scope.usa;
			console.log($scope.countrydatainfo);	
			}
		}*/	
		$scope.divShow = "div1";
  		$scope.show = function(arg) {  
			
			$scope.divShow = arg;    		
  		}

  		
});