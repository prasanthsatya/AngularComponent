var mainContent=angular.module("myApp");
		
mainContent.component("pageContent", {
	templateUrl:'maincontent/pageContent.html',	
	bindings:{
		countrybind:'<'		
	},
	controller: function($scope){
		$scope.name = this.countrybind.CountryName;
		$scope.code = this.countrybind.CountryCode;
		$scope.countryImg =this.countrybind.flagImage;
		$scope.currency = this.countrybind.Currency;
		$scope.Inr =this.countrybind.ConvertinRupee;
		//console.log($scope.name);				
	}		
});