var customSer = angular.module("myApp");
customSer.factory("countryData", function($http){

	return {
		method: function(){
			$http.get("countries.json")
				.then(function(res){
					console.log(res.data);
					return res.data;					
			});		
		}	
	}			
});