var mainContent=angular.module("myApp");
		
mainContent.component("pageContent", {
	templateUrl:'maincontent/pageContent.html',	
	bindings:{
		usa:'<',
		aus:'<',
		cn:'<',
		nz:'<'
	},
	controller: function ($scope,$http,countryData){
		/*$http.get('./countries.json')
			.then(function(res){
				$scope.demo=countryData.method();				
				$scope.name = $scope.demo.countries.USA.CountryName;
				$scope.code = $scope.demo.countries.USA.CountryCode;
				$scope.countryImg = $scope.demo.countries.USA.flagImage;
				$scope.currency = $scope.demo.countries.USA.Currency;
				$scope.Inr = $scope.demo.countries.USA.ConvertinRupee;
				console.log($scope.demo);
		});*/
		
		$scope.serData = function(){
			countryData.method.then(function(data){
				$scope.serData = data;
				console.log($scope.serData);
			});		
		}
	}		
});